﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp9
{
    internal class Vector
    {
        
        public double x1, y1, z1;
        public double x2, y2, z2;

        // Конструктор для инициализации координат
        public Vector(double x1, double y1, double z1, double x2, double y2, double z2)
        {
            this.x1 = x1;
            this.y1 = y1;
            this.z1 = z1;
            this.x2 = x2;
            this.y2 = y2;
            this.z2 = z2;
        }

        // Метод для сложения двух векторов
        public Vector Add(Vector other)
        {
            return new Vector(x1, y1, z1, x2 + other.x2, y2 + other.y2, z2 + other.z2);
        }

        // Метод для вычитания одного вектора из другого
        public Vector Subtract(Vector other)
        {
            return new Vector(x1, y1, z1, x2 - other.x2, y2 - other.y2, z2 - other.z2);
        }

        // Метод для вычисления скалярного произведения двух векторов
        public double DotProduct(Vector other)
        {
            return (x2 - x1) * (other.x2 - other.x1) + (y2 - y1) * (other.y2 - other.y1) + (z2 - z1) * (other.z2 - other.z1);
        }

        // Метод для вычисления длины вектора
        public double Length()
        {
            return Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2) + Math.Pow(z2 - z1, 2));
        }

        // Метод для вычисления косинуса угла между двумя векторами
        public double Cosine(Vector other)
        {
            double dotProduct = DotProduct(other);
            double lengthProduct = Length() * other.Length();
            return dotProduct / lengthProduct;
        }

        // Метод для вывода информации о векторе
        public void PrintVector()
        {
            Console.WriteLine($"({x1}, {y1}, {z1}) -> ({x2}, {y2}, {z2})");
        }
    }
}
