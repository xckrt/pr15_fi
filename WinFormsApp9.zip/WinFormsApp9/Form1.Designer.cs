﻿namespace WinFormsApp9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonAdd = new Button();
            buttonSubstract = new Button();
            buttonDotProduct = new Button();
            buttonLength = new Button();
            buttonCosine = new Button();
            textBoxX1 = new TextBox();
            textBoxResult = new TextBox();
            textBoxZ2 = new TextBox();
            textBoxY2 = new TextBox();
            textBoxZ1 = new TextBox();
            textBoxX2 = new TextBox();
            textBoxY1 = new TextBox();
            textBoxY3 = new TextBox();
            textBoxX4 = new TextBox();
            textBoxZ3 = new TextBox();
            textBoxY4 = new TextBox();
            textBoxZ4 = new TextBox();
            textBoxX3 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label6 = new Label();
            label7 = new Label();
            dataGridView1 = new DataGridView();
            label4 = new Label();
            label5 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // buttonAdd
            // 
            buttonAdd.FlatStyle = FlatStyle.Flat;
            buttonAdd.Location = new Point(126, 323);
            buttonAdd.Name = "buttonAdd";
            buttonAdd.Size = new Size(75, 23);
            buttonAdd.TabIndex = 0;
            buttonAdd.Text = "Сложить";
            buttonAdd.UseVisualStyleBackColor = true;
            buttonAdd.Click += buttonAdd_Click;
            // 
            // buttonSubstract
            // 
            buttonSubstract.FlatStyle = FlatStyle.Flat;
            buttonSubstract.Location = new Point(207, 323);
            buttonSubstract.Name = "buttonSubstract";
            buttonSubstract.Size = new Size(75, 23);
            buttonSubstract.TabIndex = 1;
            buttonSubstract.Text = "Вычесть";
            buttonSubstract.UseVisualStyleBackColor = true;
            buttonSubstract.Click += buttonSubtract_Click;
            // 
            // buttonDotProduct
            // 
            buttonDotProduct.FlatStyle = FlatStyle.Flat;
            buttonDotProduct.Location = new Point(403, 323);
            buttonDotProduct.Name = "buttonDotProduct";
            buttonDotProduct.Size = new Size(169, 23);
            buttonDotProduct.TabIndex = 2;
            buttonDotProduct.Text = "Скалярное произведение";
            buttonDotProduct.UseVisualStyleBackColor = true;
            buttonDotProduct.Click += buttonDotProduct_Click;
            // 
            // buttonLength
            // 
            buttonLength.FlatStyle = FlatStyle.Flat;
            buttonLength.Location = new Point(578, 323);
            buttonLength.Name = "buttonLength";
            buttonLength.Size = new Size(75, 23);
            buttonLength.TabIndex = 3;
            buttonLength.Text = "Длина";
            buttonLength.UseVisualStyleBackColor = true;
            buttonLength.Click += buttonLength_Click;
            // 
            // buttonCosine
            // 
            buttonCosine.FlatStyle = FlatStyle.Flat;
            buttonCosine.Location = new Point(288, 323);
            buttonCosine.Name = "buttonCosine";
            buttonCosine.Size = new Size(109, 23);
            buttonCosine.TabIndex = 4;
            buttonCosine.Text = "Косинус угла";
            buttonCosine.UseVisualStyleBackColor = true;
            buttonCosine.Click += buttonCosine_Click;
            // 
            // textBoxX1
            // 
            textBoxX1.Location = new Point(44, 55);
            textBoxX1.Name = "textBoxX1";
            textBoxX1.Size = new Size(100, 23);
            textBoxX1.TabIndex = 5;
            // 
            // textBoxResult
            // 
            textBoxResult.Location = new Point(384, 200);
            textBoxResult.Name = "textBoxResult";
            textBoxResult.Size = new Size(100, 23);
            textBoxResult.TabIndex = 6;
            // 
            // textBoxZ2
            // 
            textBoxZ2.Location = new Point(444, 113);
            textBoxZ2.Name = "textBoxZ2";
            textBoxZ2.Size = new Size(100, 23);
            textBoxZ2.TabIndex = 7;
            // 
            // textBoxY2
            // 
            textBoxY2.Location = new Point(163, 84);
            textBoxY2.Name = "textBoxY2";
            textBoxY2.Size = new Size(100, 23);
            textBoxY2.TabIndex = 8;
            // 
            // textBoxZ1
            // 
            textBoxZ1.Location = new Point(44, 113);
            textBoxZ1.Name = "textBoxZ1";
            textBoxZ1.Size = new Size(100, 23);
            textBoxZ1.TabIndex = 9;
            // 
            // textBoxX2
            // 
            textBoxX2.Location = new Point(163, 55);
            textBoxX2.Name = "textBoxX2";
            textBoxX2.Size = new Size(100, 23);
            textBoxX2.TabIndex = 10;
            // 
            // textBoxY1
            // 
            textBoxY1.Location = new Point(44, 84);
            textBoxY1.Name = "textBoxY1";
            textBoxY1.Size = new Size(100, 23);
            textBoxY1.TabIndex = 11;
            // 
            // textBoxY3
            // 
            textBoxY3.Location = new Point(444, 84);
            textBoxY3.Name = "textBoxY3";
            textBoxY3.Size = new Size(100, 23);
            textBoxY3.TabIndex = 17;
            // 
            // textBoxX4
            // 
            textBoxX4.Location = new Point(550, 55);
            textBoxX4.Name = "textBoxX4";
            textBoxX4.Size = new Size(100, 23);
            textBoxX4.TabIndex = 16;
            // 
            // textBoxZ3
            // 
            textBoxZ3.Location = new Point(163, 113);
            textBoxZ3.Name = "textBoxZ3";
            textBoxZ3.Size = new Size(100, 23);
            textBoxZ3.TabIndex = 15;
            // 
            // textBoxY4
            // 
            textBoxY4.Location = new Point(550, 84);
            textBoxY4.Name = "textBoxY4";
            textBoxY4.Size = new Size(100, 23);
            textBoxY4.TabIndex = 14;
            // 
            // textBoxZ4
            // 
            textBoxZ4.Location = new Point(550, 113);
            textBoxZ4.Name = "textBoxZ4";
            textBoxZ4.Size = new Size(100, 23);
            textBoxZ4.TabIndex = 13;
            // 
            // textBoxX3
            // 
            textBoxX3.Location = new Point(444, 55);
            textBoxX3.Name = "textBoxX3";
            textBoxX3.Size = new Size(100, 23);
            textBoxX3.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 55);
            label1.Name = "label1";
            label1.Size = new Size(14, 15);
            label1.TabIndex = 18;
            label1.Text = "X";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(89, 38);
            label2.Name = "label2";
            label2.Size = new Size(13, 15);
            label2.TabIndex = 19;
            label2.Text = "1";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(209, 38);
            label3.Name = "label3";
            label3.Size = new Size(13, 15);
            label3.TabIndex = 20;
            label3.Text = "2";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(12, 84);
            label6.Name = "label6";
            label6.Size = new Size(14, 15);
            label6.TabIndex = 23;
            label6.Text = "Y";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(12, 116);
            label7.Name = "label7";
            label7.Size = new Size(14, 15);
            label7.TabIndex = 24;
            label7.Text = "Z";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(676, 9);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(624, 429);
            dataGridView1.TabIndex = 25;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(489, 38);
            label4.Name = "label4";
            label4.Size = new Size(13, 15);
            label4.TabIndex = 26;
            label4.Text = "1";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(424, 58);
            label5.Name = "label5";
            label5.Size = new Size(14, 15);
            label5.TabIndex = 27;
            label5.Text = "X";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(424, 87);
            label8.Name = "label8";
            label8.Size = new Size(14, 15);
            label8.TabIndex = 28;
            label8.Text = "Y";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(424, 116);
            label9.Name = "label9";
            label9.Size = new Size(14, 15);
            label9.TabIndex = 29;
            label9.Text = "Z";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(593, 38);
            label10.Name = "label10";
            label10.Size = new Size(13, 15);
            label10.TabIndex = 30;
            label10.Text = "2";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(126, 9);
            label11.Name = "label11";
            label11.Size = new Size(54, 15);
            label11.TabIndex = 31;
            label11.Text = "Вектор 1";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(518, 9);
            label12.Name = "label12";
            label12.Size = new Size(54, 15);
            label12.TabIndex = 32;
            label12.Text = "Вектор 2";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1312, 450);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dataGridView1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textBoxY3);
            Controls.Add(textBoxX4);
            Controls.Add(textBoxZ3);
            Controls.Add(textBoxY4);
            Controls.Add(textBoxZ4);
            Controls.Add(textBoxX3);
            Controls.Add(textBoxY1);
            Controls.Add(textBoxX2);
            Controls.Add(textBoxZ1);
            Controls.Add(textBoxY2);
            Controls.Add(textBoxZ2);
            Controls.Add(textBoxResult);
            Controls.Add(textBoxX1);
            Controls.Add(buttonCosine);
            Controls.Add(buttonLength);
            Controls.Add(buttonDotProduct);
            Controls.Add(buttonSubstract);
            Controls.Add(buttonAdd);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonAdd;
        private Button buttonSubstract;
        private Button buttonDotProduct;
        private Button buttonLength;
        private Button buttonCosine;
        private TextBox textBoxX1;
        private TextBox textBoxResult;
        private TextBox textBoxZ2;
        private TextBox textBoxY2;
        private TextBox textBoxZ1;
        private TextBox textBoxX2;
        private TextBox textBoxY1;
        private TextBox textBoxY3;
        private TextBox textBoxX4;
        private TextBox textBoxZ3;
        private TextBox textBoxY4;
        private TextBox textBoxZ4;
        private TextBox textBoxX3;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label6;
        private Label label7;
        private DataGridView dataGridView1;
        private Label label4;
        private Label label5;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
    }
}