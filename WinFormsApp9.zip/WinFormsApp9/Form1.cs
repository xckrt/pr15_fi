namespace WinFormsApp9
{
    public partial class Form1 : Form
    {
        private Vector vector1;
        private Vector vector2;
        private List<Vector> vectors = new List<Vector>();
        public Form1()
        {
            InitializeComponent();

            dataGridView1.Columns.Add("X1", "X1");
            dataGridView1.Columns.Add("Y1", "Y1");
            dataGridView1.Columns.Add("Z1", "Z1");
            dataGridView1.Columns.Add("X2", "X2");
            dataGridView1.Columns.Add("Y2", "Y2");
            dataGridView1.Columns.Add("Z2", "Z2");
        }



        private void buttonAdd_Click(object sender, EventArgs e)
        {
            UpdateVectors();
            Vector result = vector1.Add(vector2);
            textBoxResult.Text = result.ToString();

            UpdateDataGridView();
        }

        private void buttonSubtract_Click(object sender, EventArgs e)
        {
            UpdateVectors();
            Vector result = vector1.Subtract(vector2);
            textBoxResult.Text = result.ToString();

            UpdateDataGridView();
        }

        private void buttonDotProduct_Click(object sender, EventArgs e)
        {
            UpdateVectors();
            double result = vector1.DotProduct(vector2);
            textBoxResult.Text = result.ToString();

            UpdateDataGridView();
        }

        private void buttonLength_Click(object sender, EventArgs e)
        {
            UpdateVectors();
            double result = vector1.Length();
            textBoxResult.Text = result.ToString();

            UpdateDataGridView();
        }

        private void buttonCosine_Click(object sender, EventArgs e)
        {
            UpdateVectors();
            double result = vector1.Cosine(vector2);
            textBoxResult.Text = result.ToString();

            UpdateDataGridView();
        }
        private void UpdateDataGridView()
        {

            dataGridView1.Rows.Clear();


            foreach (Vector vector in vectors)
            {
                dataGridView1.Rows.Add(vector.x1, vector.y1, vector.z1, vector.x2, vector.y2, vector.z2);
            }
        }0
        private void UpdateVectors()
        {
            double x1 = double.Parse(textBoxX1.Text);
            double y1 = double.Parse(textBoxY1.Text);
            double z1 = double.Parse(textBoxZ1.Text);
            double x2 = double.Parse(textBoxX2.Text);
            double y2 = double.Parse(textBoxY2.Text);
            double z2 = double.Parse(textBoxZ2.Text);

            vector1 = new Vector(x1, y1, z1, x2, y2, z2);
            vectors.Add(vector1);

            x1 = double.Parse(textBoxX3.Text);
            y1 = double.Parse(textBoxY3.Text);
            z1 = double.Parse(textBoxZ3.Text);
            x2 = double.Parse(textBoxX4.Text);
            y2 = double.Parse(textBoxY4.Text);
            z2 = double.Parse(textBoxZ4.Text);

            vector2 = new Vector(x1, y1, z1, x2, y2, z2);
            vectors.Add(vector2);
        }
    }
}